# Diamond Lane Rhythm Game

A browser-based rhythm game with a chart editor and freeplay mode.

## How to Use Charts

### Playing Charts

1. **Demo Chart**: Click "Play Game" > "Demo Song" to play the built-in demo chart.

2. **Freeplay Mode**: Click "Play Game" > "Freeplay" to access charts from your local charts folder.

3. **Adding Custom Charts**: There are several ways to add custom charts:
   - Drag and drop JSON chart files directly into the Freeplay menu
   - Save charts from the Chart Editor to your charts folder
   - Manually add chart files to the `charts` directory

### Updating the Chart Index

After adding new chart files to the `charts` directory, click the "Update Chart Index" button in the Freeplay menu to refresh the list of available charts.

### Chart File Format

Chart files are JSON files with the following structure:

```json
{
  "title": "My Custom Chart",
  "bpm": 120,
  "offset": 0,
  "duration": 60,
  "notes": [
    { "time": 1.0, "lane": 0, "speed": 4 },
    { "time": 1.5, "lane": 2, "speed": 3 },
    ...
  ]
}
```

- **title**: The name of the chart (displayed in freeplay menu)
- **bpm**: Beats per minute
- **offset**: Time offset in seconds (optional)
- **duration**: Chart duration in seconds
- **notes**: Array of note objects:
  - **time**: When the note should be hit (in seconds)
  - **lane**: Lane index (0-3, left to right)
  - **speed**: Note falling speed

## Creating Charts

Use the built-in Chart Editor to create custom charts:

1. Click "Chart Editor" from the main menu
2. Set the chart title, BPM, and duration
3. Click on the timeline to place notes
4. Use the lane selector to choose which lane to place notes in
5. Set note speed as desired
6. Right-click on notes to remove them
7. Save your chart when finished

## Controls

- **Arrow Keys**: Hit notes
- **Timeline Navigation**: Use left/right arrow keys to scroll the timeline in the editor
- **Note Placement**: Click on the timeline to place notes
- **Note Removal**: Right-click on notes to remove them 
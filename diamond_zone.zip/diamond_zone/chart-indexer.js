/**
 * Chart Directory Indexer
 * 
 * This script scans the charts directory for JSON files and creates/updates
 * an index.json file that lists all available charts.
 * 
 * Usage: 
 * 1. Include this script in your HTML page
 * 2. Call updateChartIndex() to refresh the chart index
 */

function updateChartIndex() {
  const indexPath = 'charts/index.json';
  
  // Function to list all JSON files in the charts directory
  async function scanChartsDirectory() {
    try {
      const fileInput = document.createElement('input');
      fileInput.type = 'file';
      fileInput.webkitdirectory = true;
      fileInput.directory = true;
      fileInput.style.display = 'none';
      
      document.body.appendChild(fileInput);
      
      // Create a promise that resolves when files are selected
      const filesPromise = new Promise((resolve) => {
        fileInput.addEventListener('change', () => {
          const files = Array.from(fileInput.files);
          resolve(files);
          document.body.removeChild(fileInput);
        });
        
        // Automatically try to open the charts directory
        fileInput.click();
      });
      
      const files = await filesPromise;
      
      // Filter for JSON files in the charts directory
      const chartFiles = files
        .filter(file => file.name.endsWith('.json'))
        .filter(file => {
          const path = file.webkitRelativePath || file.relativePath || file.name;
          return path.includes('charts/') && file.name !== 'index.json';
        })
        .map(file => file.name);
      
      return chartFiles;
    } catch (error) {
      console.error('Error scanning charts directory:', error);
      return [];
    }
  }
  
  // Function to update the index.json file
  async function writeIndexFile(chartFiles) {
    try {
      const indexData = {
        charts: chartFiles
      };
      
      const blob = new Blob([JSON.stringify(indexData, null, 2)], { type: 'application/json' });
      const downloadLink = document.createElement('a');
      downloadLink.href = URL.createObjectURL(blob);
      downloadLink.download = 'index.json';
      downloadLink.textContent = 'Download index.json';
      downloadLink.className = 'download-button';
      
      document.body.appendChild(downloadLink);
      
      alert('Chart index updated! Click the download button to save the index.json file to your charts directory.');
      
      return true;
    } catch (error) {
      console.error('Error writing index file:', error);
      return false;
    }
  }
  
  // Execute the indexing process
  return scanChartsDirectory().then(writeIndexFile);
}

// Add a button to the UI for updating the chart index
function addUpdateIndexButton() {
  const button = document.createElement('button');
  button.textContent = 'Update Chart Index';
  button.id = 'update-chart-index';
  button.className = 'index-button';
  button.addEventListener('click', updateChartIndex);
  
  // Add after the freeplay back button
  const freeplayBackButton = document.getElementById('freeplay-back-button');
  if (freeplayBackButton) {
    freeplayBackButton.parentNode.insertBefore(button, freeplayBackButton);
  }
}

// Call this when the document is loaded
document.addEventListener('DOMContentLoaded', addUpdateIndexButton); 
class ChartEditor {
  constructor() {
    this.chartData = {
      title: "New Chart",
      bpm: 120,
      offset: 0,
      duration: 60,
      notes: []
    };
    
    this.timeline = document.querySelector('.editor-timeline');
    this.timelineRuler = document.getElementById('timeline-ruler');
    this.timelineLanes = document.querySelectorAll('.timeline-lane');
    this.timelineCursor = document.getElementById('timeline-cursor');
    
    this.chartTitle = document.getElementById('chart-title');
    this.chartBpm = document.getElementById('chart-bpm');
    this.chartDuration = document.getElementById('chart-duration');
    
    this.currentTime = 0;
    this.isPlaying = false;
    this.selectedLane = 0;
    this.noteSpeed = 4;
    this.pixelsPerSecond = 100; // Timeline scale
    this.snapValue = 0.5; // Time snap in beats
    this.isDragging = false;
    this.startX = 0;

    this.setupEventListeners();
    this.createTimelineRuler();
    this.updateChartInfo();
    
    // Set initial selected lane
    document.querySelector('.lane-option[data-lane="0"]').classList.add('selected');
  }

  setupEventListeners() {
    // Playback controls
    document.getElementById('play-chart').addEventListener('click', () => this.playChart());
    document.getElementById('stop-chart').addEventListener('click', () => this.stopChart());
    document.getElementById('save-chart').addEventListener('click', () => this.saveChart());
    document.getElementById('load-chart').addEventListener('click', () => this.loadChart());
    document.getElementById('new-chart').addEventListener('click', () => this.newChart());
    
    // Lane selection
    const laneOptions = document.querySelectorAll('.lane-option');
    laneOptions.forEach(option => {
      option.addEventListener('click', () => {
        laneOptions.forEach(opt => opt.classList.remove('selected'));
        option.classList.add('selected');
        this.selectedLane = parseInt(option.dataset.lane);
      });
    });
    
    // Note speed setting
    const noteSpeedInput = document.getElementById('note-speed');
    const speedValue = document.getElementById('speed-value');
    noteSpeedInput.addEventListener('input', () => {
      this.noteSpeed = parseInt(noteSpeedInput.value);
      speedValue.textContent = this.noteSpeed;
    });
    
    // Snap setting
    const snapSelect = document.getElementById('snap-value');
    snapSelect.addEventListener('change', () => {
      this.snapValue = parseFloat(snapSelect.value);
      this.createTimelineRuler();
    });
    
    // Chart info inputs
    this.chartTitle.addEventListener('input', () => this.chartData.title = this.chartTitle.value);
    this.chartBpm.addEventListener('input', () => {
      this.chartData.bpm = parseInt(this.chartBpm.value);
      this.createTimelineRuler();
    });
    this.chartDuration.addEventListener('input', () => {
      this.chartData.duration = parseInt(this.chartDuration.value);
      this.createTimelineRuler();
    });
    
    // Timeline interaction
    this.timeline.addEventListener('click', (e) => {
      if (e.target.classList.contains('timeline-lane') || e.target.classList.contains('timeline-lanes')) {
        const rect = this.timeline.getBoundingClientRect();
        const clickX = e.clientX - rect.left + this.timeline.scrollLeft;
        const lane = this.getLaneFromEvent(e);
        
        if (lane !== null) {
          const time = this.getSnappedTime(clickX / this.pixelsPerSecond);
          this.addNote(time, lane);
        }
      }
    });
    
    // Cursor dragging in timeline
    this.timeline.addEventListener('mousedown', (e) => {
      this.isDragging = true;
      this.startX = e.clientX;
      
      const rect = this.timeline.getBoundingClientRect();
      const clickX = e.clientX - rect.left + this.timeline.scrollLeft;
      this.setCurrentTime(clickX / this.pixelsPerSecond);
    });
    
    document.addEventListener('mousemove', (e) => {
      if (this.isDragging) {
        const rect = this.timeline.getBoundingClientRect();
        const clickX = e.clientX - rect.left + this.timeline.scrollLeft;
        this.setCurrentTime(Math.max(0, clickX / this.pixelsPerSecond));
      }
    });
    
    document.addEventListener('mouseup', () => {
      this.isDragging = false;
    });
    
    // Note deletion
    this.timeline.addEventListener('contextmenu', (e) => {
      if (e.target.classList.contains('note-marker')) {
        e.preventDefault();
        const noteId = e.target.dataset.noteId;
        this.removeNote(noteId);
      }
    });
    
    // Keyboard navigation for horizontal scrolling
    document.addEventListener('keydown', (e) => {
      if (!document.getElementById('editor-container').classList.contains('active')) return;
      
      const scrollAmount = 100;
      if (e.key === 'ArrowRight') {
        e.preventDefault();
        this.timeline.scrollLeft += scrollAmount;
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        this.timeline.scrollLeft = Math.max(0, this.timeline.scrollLeft - scrollAmount);
      }
    });
  }

  getLaneFromEvent(e) {
    for (let i = 0; i < this.timelineLanes.length; i++) {
      const lane = this.timelineLanes[i];
      const rect = lane.getBoundingClientRect();
      if (e.clientY >= rect.top && e.clientY <= rect.bottom) {
        return parseInt(lane.dataset.lane);
      }
    }
    return null;
  }

  getSnappedTime(time) {
    const beatTime = 60 / this.chartData.bpm;
    const snapTime = beatTime * this.snapValue;
    return Math.round(time / snapTime) * snapTime;
  }

  addNote(time, lane) {
    const noteId = Date.now().toString(); // Unique ID for the note
    const note = {
      id: noteId,
      time: time,
      lane: lane,
      speed: this.noteSpeed
    };
    
    this.chartData.notes.push(note);
    this.renderNote(note);
  }

  removeNote(noteId) {
    const noteElement = document.querySelector(`.note-marker[data-note-id="${noteId}"]`);
    if (noteElement) {
      noteElement.remove();
    }
    
    this.chartData.notes = this.chartData.notes.filter(note => note.id !== noteId);
  }

  renderNote(note) {
    const noteElement = document.createElement('div');
    noteElement.className = 'note-marker';
    noteElement.dataset.noteId = note.id;
    noteElement.style.backgroundImage = `url('/note.png')`;
    
    // Add lane-specific class
    switch (note.lane) {
      case 0: noteElement.classList.add('pink-hue'); break;
      case 1: noteElement.classList.add('blue-hue'); break;
      case 2: noteElement.classList.add('green-hue'); break;
      case 3: noteElement.classList.add('red-hue'); break;
    }
    
    // Position the note - using snapped time to ensure grid alignment
    const snappedTime = this.getSnappedTime(note.time);
    const xPos = snappedTime * this.pixelsPerSecond;
    noteElement.style.left = `${xPos}px`;
    
    const laneElement = this.timelineLanes[note.lane];
    const laneHeight = laneElement.offsetHeight;
    noteElement.style.top = `${laneHeight / 2}px`;
    
    laneElement.appendChild(noteElement);
  }

  createTimelineRuler() {
    this.timelineRuler.innerHTML = '';
    const duration = this.chartData.duration;
    const bpm = this.chartData.bpm;
    const beatDuration = 60 / bpm; // Duration of one beat in seconds
    
    // Set timeline width based on duration
    const timelineWidth = duration * this.pixelsPerSecond;
    this.timelineRuler.style.width = `${timelineWidth}px`;
    this.timelineLanes.forEach(lane => {
      lane.style.width = `${timelineWidth}px`;
    });
    
    // Create tick marks
    for (let second = 0; second <= duration; second++) {
      // For each second
      const isMajorTick = second % 4 === 0;
      const tick = document.createElement('div');
      tick.className = `timeline-tick ${isMajorTick ? 'major' : ''}`;
      tick.style.left = `${second * this.pixelsPerSecond}px`;
      
      if (isMajorTick) {
        const tickLabel = document.createElement('div');
        tickLabel.className = 'timeline-tick-label';
        tickLabel.textContent = second;
        tickLabel.style.left = `${second * this.pixelsPerSecond}px`;
        this.timelineRuler.appendChild(tickLabel);
      }
      
      this.timelineRuler.appendChild(tick);
    }
    
    // Create beat ticks
    const totalBeats = Math.ceil(duration / beatDuration);
    for (let beat = 0; beat <= totalBeats; beat++) {
      const beatPosition = beat * beatDuration;
      
      // Skip if this is also a second marker
      if (Math.abs(Math.round(beatPosition) - beatPosition) < 0.01) continue;
      
      const tick = document.createElement('div');
      tick.className = 'timeline-tick';
      tick.style.left = `${beatPosition * this.pixelsPerSecond}px`;
      this.timelineRuler.appendChild(tick);
    }
  }

  renderAllNotes() {
    // Clear existing notes
    this.timelineLanes.forEach(lane => {
      const notes = lane.querySelectorAll('.note-marker');
      notes.forEach(note => note.remove());
    });
    
    // Render all notes
    this.chartData.notes.forEach(note => {
      this.renderNote(note);
    });
  }

  playChart() {
    this.isPlaying = true;
    const startTime = performance.now() / 1000 - this.currentTime;
    
    const updatePlayback = () => {
      if (!this.isPlaying) return;
      
      const now = performance.now() / 1000;
      this.currentTime = now - startTime;
      
      if (this.currentTime >= this.chartData.duration) {
        this.stopChart();
        return;
      }
      
      this.updateCursor();
      requestAnimationFrame(updatePlayback);
    };
    
    updatePlayback();
  }

  stopChart() {
    this.isPlaying = false;
  }

  setCurrentTime(time) {
    this.currentTime = Math.min(Math.max(0, time), this.chartData.duration);
    this.updateCursor();
  }

  updateCursor() {
    const position = this.currentTime * this.pixelsPerSecond;
    this.timelineCursor.style.left = `${position}px`;
    
    // Auto-scroll timeline if cursor is out of view
    if (this.isPlaying) {
      const timelineRect = this.timeline.getBoundingClientRect();
      const cursorPosition = position;
      
      if (cursorPosition > this.timeline.scrollLeft + timelineRect.width * 0.8) {
        this.timeline.scrollLeft = cursorPosition - timelineRect.width * 0.5;
      }
    }
  }

  saveChart() {
    // Create a copy of chart data without internal IDs
    const chartDataToSave = {
      title: this.chartData.title,
      bpm: this.chartData.bpm,
      offset: this.chartData.offset,
      duration: this.chartData.duration,
      notes: this.chartData.notes.map(note => ({
        time: note.time,
        lane: note.lane,
        speed: note.speed
      }))
    };
    
    const jsonString = JSON.stringify(chartDataToSave, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    // Sanitize the filename and suggest saving to the charts directory
    const safeFilename = this.chartData.title.replace(/[^a-zA-Z0-9_\-]/g, '_').toLowerCase();
    a.download = `${safeFilename}.json`;
    
    // Show save dialog with instructions
    const saveDialog = document.createElement('div');
    saveDialog.className = 'save-dialog';
    saveDialog.innerHTML = `
      <div class="save-dialog-content">
        <h2>Save Chart</h2>
        <p>To make this chart appear in the freeplay menu:</p>
        <ol>
          <li>Save this file to the "charts" folder</li>
          <li>Then click "Update Chart Index" in the freeplay menu</li>
        </ol>
        <div class="save-dialog-buttons">
          <button id="save-download">Download Chart</button>
          <button id="save-cancel">Cancel</button>
        </div>
      </div>
    `;
    
    document.body.appendChild(saveDialog);
    
    // Handle button clicks
    document.getElementById('save-download').addEventListener('click', () => {
      a.click();
      URL.revokeObjectURL(url);
      document.body.removeChild(saveDialog);
    });
    
    document.getElementById('save-cancel').addEventListener('click', () => {
      URL.revokeObjectURL(url);
      document.body.removeChild(saveDialog);
    });
  }

  loadChart() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    
    input.onchange = e => {
      const file = e.target.files[0];
      if (!file) return;
      
      const reader = new FileReader();
      reader.onload = event => {
        try {
          const chartData = JSON.parse(event.target.result);
          this.loadChartData(chartData);
        } catch (error) {
          console.error('Error parsing chart file:', error);
          alert('Invalid chart file format');
        }
      };
      reader.readAsText(file);
    };
    
    input.click();
  }

  loadChartData(chartData) {
    // Validate chart data
    if (!chartData.title || !chartData.bpm || !chartData.notes) {
      alert('Invalid chart data format');
      return;
    }
    
    // Add IDs to notes if they don't have them
    chartData.notes = chartData.notes.map(note => ({
      ...note,
      id: note.id || Date.now() + Math.random().toString(36).substr(2, 9)
    }));
    
    this.chartData = chartData;
    this.updateChartInfo();
    this.createTimelineRuler();
    this.renderAllNotes();
  }

  newChart() {
    if (confirm('Create new chart? Unsaved changes will be lost.')) {
      this.chartData = {
        title: "New Chart",
        bpm: 120,
        offset: 0,
        duration: 60,
        notes: []
      };
      
      this.updateChartInfo();
      this.createTimelineRuler();
      this.renderAllNotes();
    }
  }

  updateChartInfo() {
    this.chartTitle.value = this.chartData.title;
    this.chartBpm.value = this.chartData.bpm;
    this.chartDuration.value = this.chartData.duration;
  }
}

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', () => {
  // Editor will be initialized when that screen becomes active
});
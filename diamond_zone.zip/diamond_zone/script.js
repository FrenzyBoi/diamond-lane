document.addEventListener('DOMContentLoaded', () => {
  const diamonds = document.querySelectorAll('.diamond-icon');
  const lanes = document.querySelectorAll('.lane');
  const noteLanes = document.querySelectorAll('.note-lane');
  const scoreDisplay = document.getElementById('score');

  // Screen management
  const mainMenu = document.getElementById('main-menu');
  const playMenu = document.getElementById('play-menu');
  const freeplayMenu = document.getElementById('freeplay-menu');
  const gameContainer = document.getElementById('game-container');
  const editorContainer = document.getElementById('editor-container');
  
  // Navigation buttons
  const playButton = document.getElementById('play-button');
  const demoButton = document.getElementById('demo-button');
  const freeplayButton = document.getElementById('freeplay-button');
  const editorButton = document.getElementById('editor-button');
  const backButton = document.getElementById('back-button');
  const playBackButton = document.getElementById('play-back-button');
  const freeplayBackButton = document.getElementById('freeplay-back-button');
  const editorBackButton = document.getElementById('editor-back-button');
  
  const songList = document.getElementById('song-list');
  
  let degrees = 0;
  let noteChart;
  let chartEditor;
  let loadedCharts = [];
  
  // Setup drag and drop for chart files
  setupChartDropZone(freeplayMenu);
  
  function setupChartDropZone(dropZone) {
    // Prevent default to allow drop
    dropZone.addEventListener('dragover', (e) => {
      e.stopPropagation();
      e.preventDefault();
      e.dataTransfer.dropEffect = 'copy';
      dropZone.classList.add('dragover');
    });
    
    // Handle dragover leaving
    dropZone.addEventListener('dragleave', () => {
      dropZone.classList.remove('dragover');
    });
    
    // Handle the dropped files
    dropZone.addEventListener('drop', (e) => {
      e.stopPropagation();
      e.preventDefault();
      dropZone.classList.remove('dragover');
      
      const files = Array.from(e.dataTransfer.files);
      
      // Filter for JSON files
      const jsonFiles = files.filter(file => file.name.endsWith('.json'));
      
      if (jsonFiles.length === 0) {
        alert('Please drop JSON chart files only.');
        return;
      }
      
      // Process each dropped JSON file
      jsonFiles.forEach(file => {
        processChartFile(file);
      });
    });
  }
  
  // Process a chart file that was dropped or selected
  function processChartFile(file) {
    const reader = new FileReader();
    
    reader.onload = function(e) {
      try {
        const chartData = JSON.parse(e.target.result);
        
        // Validate that this is a chart file
        if (!chartData.notes || !Array.isArray(chartData.notes)) {
          console.warn(`File ${file.name} does not appear to be a valid chart file.`);
          return;
        }
        
        // Create a temporary URL for the file
        const chartUrl = URL.createObjectURL(file);
        
        // Add to loaded charts
        const chartInfo = {
          title: chartData.title || 'Unnamed Chart',
          bpm: chartData.bpm || 120,
          noteCount: chartData.notes.length,
          filename: file.name,
          url: chartUrl,
          file: file
        };
        
        // Check if chart with same name already exists
        const existingIndex = loadedCharts.findIndex(c => c.filename === file.name);
        if (existingIndex >= 0) {
          loadedCharts[existingIndex] = chartInfo;
        } else {
          loadedCharts.push(chartInfo);
        }
        
        // Refresh the song list display
        updateSongListDisplay();
      } catch (error) {
        console.error(`Error processing chart file ${file.name}:`, error);
      }
    };
    
    reader.readAsText(file);
  }
  
  // Update the song list display with all loaded charts
  function updateSongListDisplay() {
    songList.innerHTML = '';
    
    if (loadedCharts.length === 0) {
      songList.innerHTML = '<div class="no-songs">No songs available. Drop chart files here!</div>';
      return;
    }
    
    loadedCharts.forEach(chart => {
      const songItem = document.createElement('div');
      songItem.className = 'song-item';
      songItem.innerHTML = `
        <div class="song-title">${chart.title}</div>
        <div class="song-info">BPM: ${chart.bpm} | Notes: ${chart.noteCount}</div>
      `;
      songItem.addEventListener('click', () => {
        showScreen(gameContainer);
        initGame(chart.url);
      });
      songList.appendChild(songItem);
    });
  }
  
  function rotateDiamonds() {
    degrees += 1;
    diamonds.forEach(diamond => {
      diamond.style.transform = `rotate(${degrees}deg)`;
    });
    requestAnimationFrame(rotateDiamonds);
  }

  requestAnimationFrame(rotateDiamonds);

  // Screen navigation
  function showScreen(screen) {
    [mainMenu, playMenu, freeplayMenu, gameContainer, editorContainer].forEach(s => {
      s.classList.remove('active');
    });
    screen.classList.add('active');
  }

  playButton.addEventListener('click', () => {
    showScreen(playMenu);
  });
  
  demoButton.addEventListener('click', () => {
    showScreen(gameContainer);
    initGame('charts/songchart.json');
  });
  
  freeplayButton.addEventListener('click', () => {
    loadSongList();
    showScreen(freeplayMenu);
  });

  editorButton.addEventListener('click', () => {
    showScreen(editorContainer);
    initEditor();
  });

  backButton.addEventListener('click', () => {
    showScreen(mainMenu);
    if (noteChart) {
      noteChart.isPlaying = false;
    }
  });
  
  playBackButton.addEventListener('click', () => {
    showScreen(mainMenu);
  });
  
  freeplayBackButton.addEventListener('click', () => {
    showScreen(playMenu);
  });

  editorBackButton.addEventListener('click', () => {
    showScreen(mainMenu);
  });
  
  // Load available songs
  async function loadSongList() {
    try {
      // Use the FileReader API to read all chart files from the local charts directory
      songList.innerHTML = '<div class="loading">Loading charts...</div>';
      
      // We'll scan the charts directory using an array of predefined chart files
      // This is a placeholder for the actual file list
      const chartFiles = ['songchart.json'];
      
      // Try to load any additional chart files dynamically
      try {
        const response = await fetch('charts/index.json');
        if (response.ok) {
          const indexData = await response.json();
          if (Array.isArray(indexData.charts)) {
            chartFiles.push(...indexData.charts.filter(chart => !chartFiles.includes(chart)));
          }
        }
      } catch (e) {
        console.log("No index.json found, using default charts only");
      }
      
      loadedCharts = [];
      
      // Load each chart's metadata
      for (const filename of chartFiles) {
        try {
          const response = await fetch(`charts/${filename}`);
          if (response.ok) {
            const chartData = await response.json();
            loadedCharts.push({
              title: chartData.title || 'Unnamed Chart',
              bpm: chartData.bpm || 120,
              noteCount: chartData.notes ? chartData.notes.length : 0,
              filename: filename,
              url: `charts/${filename}`
            });
          }
        } catch (e) {
          console.error(`Error loading chart ${filename}:`, e);
        }
      }
      
      updateSongListDisplay();
    } catch (error) {
      console.error("Error loading song list:", error);
      songList.innerHTML = '<div class="no-songs">Failed to load songs</div>';
    }
  }

  // Game initialization
  function initGame(chartPath) {
    // Initialize the note chart system using the version from chart.js
    noteChart = new NoteChartSystem(noteLanes, scoreDisplay);
    noteChart.loadChart(chartPath)
      .then(success => {
        if (success) {
          console.log("Chart loaded successfully");
        } else {
          console.warn("Failed to load chart, falling back to random notes");
        }
        noteChart.startNoteGeneration();
      });
      
    // Handle key events for arrow keys
    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('keyup', handleKeyUp);
  }

  function handleKeyDown(event) {
    lanes.forEach((lane, index) => {
      if (event.key === lane.dataset.key) {
        lane.querySelector('.diamond-icon').classList.add('brightened');
        if (noteChart) {
          noteChart.checkNoteHit(lane.dataset.key, index);
        }
      }
    });
  }

  function handleKeyUp(event) {
    lanes.forEach(lane => {
      if (event.key === lane.dataset.key) {
        lane.querySelector('.diamond-icon').classList.remove('brightened');
      }
    });
  }

  // Editor initialization
  function initEditor() {
    if (!chartEditor) {
      chartEditor = new ChartEditor();
    }
  }

  // Show main menu initially
  showScreen(mainMenu);
});